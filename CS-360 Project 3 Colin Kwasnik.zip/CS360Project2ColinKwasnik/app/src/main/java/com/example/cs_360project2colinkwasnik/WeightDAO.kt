package com.example.cs_360project2colinkwasnik

import android.content.ContentValues
import android.content.Context

class WeightDAO(context: Context) {
    private val dbHelper = DBHelper(context)

    fun addWeight(entry: WeightEntry) {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("date", entry.date)
            put("weight", entry.weight)
        }
        db.insert("weights", null, values)
    }

    fun deleteWeight(id: Int) {
        val db = dbHelper.writableDatabase
        db.delete("weights", "id=?", arrayOf(id.toString()))
    }

    fun getAllWeights(): List<WeightEntry> {
        val list = mutableListOf<WeightEntry>()
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM weights ORDER BY date DESC", null)
        while (cursor.moveToNext()) {
            list.add(
                WeightEntry(
                    id = cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                    date = cursor.getString(cursor.getColumnIndexOrThrow("date")),
                    weight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"))
                )
            )
        }
        cursor.close()
        return list
    }
}
