package com.example.cs_360project2colinkwasnik

data class WeightEntry(
    val id: Int,
    val date: String,
    val weight: Double
)