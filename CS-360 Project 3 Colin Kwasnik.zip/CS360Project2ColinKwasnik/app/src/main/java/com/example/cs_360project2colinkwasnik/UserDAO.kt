package com.example.cs_360project2colinkwasnik

import android.content.ContentValues
import android.content.Context

class UserDAO(context: Context) {
    private val dbHelper = DBHelper(context)

    fun login(username: String, password: String): Boolean {
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery(
            "SELECT * FROM users WHERE username=? AND password=?",
            arrayOf(username, password)
        )
        val exists = cursor.moveToFirst()
        cursor.close()
        return exists
    }

    fun register(username: String, password: String): Boolean {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("username", username)
            put("password", password)
        }
        val result = db.insert("users", null, values)
        return result != -1L
    }
}