package com.example.cs_360project2colinkwasnik

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.cs_360project2colinkwasnik.MainActivity


class LoginActivity : AppCompatActivity() {
    private lateinit var userDAO: UserDAO

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        userDAO = UserDAO(this)

        val etUsername: EditText = findViewById(R.id.et_username)
        val etPassword: EditText = findViewById(R.id.et_password)
        val btnLogin: Button = findViewById(R.id.btn_login)
        val btnCreateAccount: Button = findViewById(R.id.btn_create_account)

        btnLogin.setOnClickListener {
            val user = etUsername.text.toString()
            val pass = etPassword.text.toString()
            if (userDAO.login(user, pass)) {
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, MainActivity::class.java))

            } else {
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show()
            }
        }

        btnCreateAccount.setOnClickListener {
            val user = etUsername.text.toString()
            val pass = etPassword.text.toString()
            if (userDAO.register(user, pass)) {
                Toast.makeText(this, "Account Created!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Error: Username may already exist", Toast.LENGTH_SHORT).show()
            }
        }
    }
}