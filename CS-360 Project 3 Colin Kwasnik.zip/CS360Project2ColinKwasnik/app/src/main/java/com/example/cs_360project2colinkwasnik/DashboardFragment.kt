package com.example.cs_360project2colinkwasnik

import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.time.LocalDate

class DashboardFragment : Fragment(R.layout.activity_dashboard) {

    private lateinit var weightDao: WeightDAO
    private lateinit var adapter: WeightAdapter

    override fun onViewCreated(view: android.view.View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val weightInput: EditText = view.findViewById(R.id.et_weight_input)
        val fabAddEntry: FloatingActionButton = view.findViewById(R.id.fab_add_entry)
        val recyclerView: RecyclerView = view.findViewById(R.id.rv_weight_grid)

        weightDao = WeightDAO(requireContext())
        adapter = WeightAdapter(mutableListOf(), weightDao)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter

        loadWeightEntries()

        fabAddEntry.setOnClickListener {
            val weightText = weightInput.text.toString()
            val weightValue = weightText.toDoubleOrNull()
            if (weightValue != null) {
                val newEntry = WeightEntry(0, LocalDate.now().toString(), weightValue)
                Thread {
                    weightDao.addWeight(newEntry)
                    val updatedList = weightDao.getAllWeights()
                    activity?.runOnUiThread {
                        adapter.setItems(updatedList)
                        weightInput.text.clear()
                    }
                }.start()
            } else {
                Toast.makeText(requireContext(), "Invalid number", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadWeightEntries() {
        Thread {
            val entries = weightDao.getAllWeights()
            activity?.runOnUiThread { adapter.setItems(entries) }
        }.start()
    }
}
