package com.example.cs_360project2colinkwasnik

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class WeightAdapter(
    private val weightList: MutableList<WeightEntry>,
    private val dao: WeightDAO
) : RecyclerView.Adapter<WeightAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_weight_entry, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val entry = weightList[position]
        holder.date.text = entry.date
        holder.weight.text = "${entry.weight} kg"

        holder.deleteBtn.setOnClickListener {
            // Delete from database
            dao.deleteWeight(entry.id)

            // Remove from RecyclerView
            weightList.removeAt(position)
            notifyItemRemoved(position)
        }
    }

    override fun getItemCount(): Int = weightList.size

    // Add a new item dynamically
    fun addItem(entry: WeightEntry) {
        weightList.add(0, entry) // insert at top
        notifyItemInserted(0)
    }

    // Set items when loading from DB
    fun setItems(entries: List<WeightEntry>) {
        weightList.clear()
        weightList.addAll(entries)
        notifyDataSetChanged()
    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val date: TextView = view.findViewById(R.id.tv_date)
        val weight: TextView = view.findViewById(R.id.tv_weight)
        val deleteBtn: ImageButton = view.findViewById(R.id.btn_delete)
    }
}
