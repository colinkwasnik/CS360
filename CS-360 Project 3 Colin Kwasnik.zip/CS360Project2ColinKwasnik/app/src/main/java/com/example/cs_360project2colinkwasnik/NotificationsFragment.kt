package com.example.cs_360project2colinkwasnik

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment

class NotificationsFragment : Fragment(R.layout.activity_notifications) {

    private val SMS_PERMISSION_CODE = 100
    private val PREFS_NAME = "user_prefs"
    private val KEY_GOAL_WEIGHT = "goal_weight"
    private var goalWeight: Double = 0.0

    override fun onViewCreated(view: android.view.View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val allowBtn: Button = view.findViewById(R.id.btn_allow_sms)
        val denyBtn: Button = view.findViewById(R.id.btn_deny_sms)
        val goalAchieved: TextView = view.findViewById(R.id.tv_goal_achieved)
        val etGoalWeight: EditText = view.findViewById(R.id.et_goal_weight)
        val saveGoalBtn: Button = view.findViewById(R.id.btn_save_goal)

        // Load previously saved goal weight
        val prefs = requireContext().getSharedPreferences(PREFS_NAME, android.content.Context.MODE_PRIVATE)
        goalWeight = prefs.getFloat(KEY_GOAL_WEIGHT, 0.0f).toDouble()
        if (goalWeight > 0) etGoalWeight.setText(goalWeight.toString())

        // Save goal weight
        saveGoalBtn.setOnClickListener {
            val input = etGoalWeight.text.toString().toDoubleOrNull()
            if (input != null && input > 0) {
                goalWeight = input
                prefs.edit().putFloat(KEY_GOAL_WEIGHT, goalWeight.toFloat()).apply()
                Toast.makeText(requireContext(), "Goal weight saved!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "Enter a valid number", Toast.LENGTH_SHORT).show()
            }
        }

        // Send SMS
        allowBtn.setOnClickListener {
            if (goalWeight <= 0) {
                Toast.makeText(requireContext(), "Please set a valid goal weight first!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    requireActivity(),
                    arrayOf(Manifest.permission.SEND_SMS),
                    SMS_PERMISSION_CODE
                )
            } else {
                sendSMS("1234567890", "Congrats! You reached your goal weight of $goalWeight kg!")
                goalAchieved.visibility = TextView.VISIBLE
            }
        }

        denyBtn.setOnClickListener {
            Toast.makeText(requireContext(), "SMS Denied. App will run without notifications.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendSMS(phone: String, message: String) {
        val smsManager = SmsManager.getDefault()
        smsManager.sendTextMessage(phone, null, message, null, null)
        Toast.makeText(requireContext(), "SMS Sent!", Toast.LENGTH_SHORT).show()
    }
}
