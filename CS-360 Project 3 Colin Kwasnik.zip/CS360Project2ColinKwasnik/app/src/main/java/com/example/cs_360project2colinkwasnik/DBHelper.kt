package com.example.cs_360project2colinkwasnik

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "weight_tracker.db"
        private const val DATABASE_VERSION = 2 // incremented to handle upgrades

        // Weights table
        const val TABLE_WEIGHTS = "weights"
        const val COLUMN_ID = "id"
        const val COLUMN_DATE = "date"
        const val COLUMN_WEIGHT = "weight"

        // Users table
        const val TABLE_USERS = "users"
        const val COLUMN_USER_ID = "id"
        const val COLUMN_USERNAME = "username"
        const val COLUMN_PASSWORD = "password"
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Create weights table
        val createWeightsTable = """
            CREATE TABLE $TABLE_WEIGHTS (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_DATE TEXT NOT NULL,
                $COLUMN_WEIGHT REAL NOT NULL
            )
        """.trimIndent()
        db.execSQL(createWeightsTable)

        // Create users table
        val createUsersTable = """
            CREATE TABLE $TABLE_USERS (
                $COLUMN_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_USERNAME TEXT NOT NULL UNIQUE,
                $COLUMN_PASSWORD TEXT NOT NULL
            )
        """.trimIndent()
        db.execSQL(createUsersTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Drop old tables if they exist
        db.execSQL("DROP TABLE IF EXISTS $TABLE_WEIGHTS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")

        // Recreate tables
        onCreate(db)
    }
}
